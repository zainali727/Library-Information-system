Need to have DOtNEt core 3.1 installed.
Install dotnet tool entityframework
run "dotnet ef database update" from the WebApplication folder
Run the solution